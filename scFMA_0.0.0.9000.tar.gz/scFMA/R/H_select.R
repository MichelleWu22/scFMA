#' the number of intervals
#'
#' @param cell_length sample size
#' @param type sample type
#'
#' @return the number of intervals that need to be divided
#' @export
#'
#' @examples H_select(48,"8cell")
#'
H_select<-function(cell_length,type)
{
  if(type == "8cell"){
    if(cell_length < 25){
      H = 12
    }else{
      if(cell_length >= 25 & cell_length < 40){H = 20}else{H = 30}
    }
  }else{
    if(cell_length < 15){
      H = 7
    }else{
      if(cell_length >= 15 & cell_length < 20){H = 10}else{H = 20}
    }
  }
  return(H)
}
