
#' calculate the mean of the methylation distribution of 8-cell samples
#'
#' @param comb a matrix composed of methylation reads and total reads with a number of columns of 2
#'
#' @return The mean of the methylation distribution of 8-cell samples
#' @export
#'
boot8c_discreteMM.est<-function(comb)
{
  x_read<- comb[,1]
  n_read<-comb[,2]
  H=H_select(48,"8cell")
  phi=phi.est(H)$phi

  pai.boot<-discreteMM.est(n_read,x_read,n=length(n_read),H)$pai
  mu.boot<-sum(pai.boot*phi)

  return(mu.boot)
}
