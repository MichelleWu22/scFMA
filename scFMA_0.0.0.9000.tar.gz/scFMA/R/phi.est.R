#' midpoint between each interval
#'
#' @param H number of intervals
#'
#' @return midpoint vector(phi), vector composed of interval endpoints(tau) and the length of tau(M)
#' @export
#'
#' @examples phi.est(30)
#'
phi.est<-function(H)
{
  if(H==30){
    a=c(-0.017,1.0172)
  }else{
    if(H==12){
      a=c(-0.0452,1.0454)
    }else{
      if(H==20){
        a=c(-0.0262,1.0263)
      }else{
        if(H==10){#H=15
          #a=c(-0.0355,1.0357)
          a=c(-0.0553,1.0555)
        }else{
          if(H==7){
            a=c(-0.0831,1.0833)
          }else{#H=20
            a=c(-0.0206,1.0208)
          }
        }
      }
    }
  }
  tau<-seq(a[1],a[2],by=(a[2]-a[1])/H)
  M<-length(tau)
  phi<-(tau[-M]+tau[2:M])/2
  return(list(phi=phi,tau=tau,M=M))
}


