#' generate random numbers from discrete distribution
#'
#' @param n The number of random numbers generated
#' @param phi vector composed of interval midpoints
#' @param pai probability value of the interval
#'
#' @return random numbers
#' @export
#'
rdiscrete.appro<-function(n,phi,pai)
{
  g<-integer(n)
  FP<-cumsum(pai)
  u<-runif(n)
  FP<-c(0,FP,1)
  for(j in 1:(length(phi)))
  {
    ind<-u>FP[j] & u<=FP[j+1]
    g[ind]<-phi[j]
  }
  return(g)
}
