
#' scFMA
#'
#' @param testRegion the list generated after site filtering and region division
#' @param treadn total reads matrix
#' @param treadx methylation reads matrix
#' @param sample8c the location of the 8-cell samples
#' @param sample4c the location of the 4-cell samples
#' @param n1 the sample size of the 8-cell samples
#' @param n2 the sample size of the 4-cell samples
#'
#' @return pvalues and regional level methylation difference Δ(absd) between two types of samples
#' @export
#'
real_scFMA <- function(testRegion,treadn, treadx,sample8c,sample4c,n1,n2){

  library(foreach)
  library(iterators)
  library(parallel)
  library(doParallel)

  rep_count<-floor(length(testRegion)/100)
  reg_remain<-length(testRegion)-rep_count*100

  if(rep_count!=0){

    result<-NULL
    finial_result<-NULL

    for(rep in 1:rep_count)
    {

      cl <- makeCluster(100)
      registerDoParallel(cl)
      rets <- foreach (reg =(1+100*(rep-1)):(100*rep), .packages=c("doParallel"),
                       .inorder =TRUE, .combine ="cbind") %dopar% {

                         library(scFMA)
                         eachbinn8c <- as.matrix(testRegion[[reg]]$n[, sample8c])
                         eachbinx8c <- as.matrix(testRegion[[reg]]$x[, sample8c])
                         eachbinn4c <- as.matrix(testRegion[[reg]]$n[, sample4c])
                         eachbinx4c <- as.matrix(testRegion[[reg]]$x[, sample4c])

                         #-------parameter estimate----------
                         eight_n<-NULL
                         eight_x<-NULL
                         four_n<-NULL
                         four_x<-NULL

                         for (i in 1:dim(eachbinn8c)[1]) {
                           eight_n <- c(eight_n, eachbinn8c[i,!is.na(eachbinn8c[i,])])
                           eight_x <- c(eight_x, eachbinx8c[i,!is.na(eachbinn8c[i,])])
                           four_n <- c(four_n, eachbinn4c[i ,!is.na(eachbinn4c[i,])])
                           four_x <- c(four_x, eachbinx4c[i ,!is.na(eachbinn4c[i,])])

                         }

                         discreteMM.est8c<-discreteMM.est(eight_n,eight_x,length(eight_n),
                                                          H_select(round(length(eight_n)/dim(eachbinn8c)[1]),"8cell"))
                         pai8c<-discreteMM.est8c$pai
                         phi8c<-discreteMM.est8c$phi

                         discreteMM.est4c <- discreteMM.est(four_n,four_x,length(four_n),
                                                            H_select(round(length(four_n)/dim(eachbinn8c)[1]),"4cell"))
                         pai4c<- discreteMM.est4c$pai
                         phi4c<- discreteMM.est4c$phi


                         ###----------wald test------------------------

                         mu_8c <- sum(pai8c*phi8c)
                         mu_4c <- sum(pai4c*phi4c)


                         boot_sample8c<-vector(mode="list")
                         boot_sample4c<-vector(mode="list")


                         for(g in 1:500)
                         {
                           ###8 cell
                           eight_nnew<-sample(eight_n,size=n1*dim(eachbinn8c)[1],replace = TRUE)
                           g8c<-rdiscrete.appro(length(eight_nnew),phi8c,pai8c)
                           eight_xnew<-mapply(rbinom, n = rep(1, length(eight_nnew)), size =eight_nnew, prob =g8c)

                           #ntotal8c.new<-length(eight_nnew)
                           n8c.new_each<-round(length(eight_nnew)/dim(eachbinn8c)[1])
                           boot_sample8c[[g]]<-cbind(eight_xnew,eight_nnew)


                           ###4 cell
                           four_nnew<-sample(four_n,size=n2*dim(eachbinn4c)[1],replace = TRUE)
                           g4c<-rdiscrete.appro(length(four_nnew),phi4c,pai4c)
                           four_xnew<-mapply(rbinom, n = rep(1, length(four_nnew)), size =four_nnew, prob =g4c)

                           #ntotal4c.new<-length(four_nnew)
                           n4c.new_each<-round(length(four_nnew)/dim(eachbinn4c)[1])
                           boot_sample4c[[g]]<-cbind(four_xnew,four_nnew)


                         }

                         mu.boot8c<-sapply(boot_sample8c,boot8c_discreteMM.est)
                         mu.boot4c<-sapply(boot_sample4c,boot4c_discreteMM.est)

                         ### delta ###
                         nbin8c <- NULL
                         nbin4c <- NULL
                         xbin8c <- NULL
                         xbin4c <- NULL
                         for (i in 1:dim(eachbinn8c)[2]) {
                           nbin8c <- c(nbin8c, eachbinn8c[!is.na(eachbinn8c[,  i]), i])
                           xbin8c <- c(xbin8c, eachbinx8c[!is.na(eachbinn8c[,  i]), i])
                         }
                         for (ii in 1:dim(eachbinn4c)[2]) {
                           nbin4c <- c(nbin4c, eachbinn4c[!is.na(eachbinn4c[,  ii]), ii])
                           xbin4c <- c(xbin4c, eachbinx4c[!is.na(eachbinn4c[,  ii]), ii])
                         }


                         ntotal8c <- length(nbin8c)
                         ntotal4c <- length(nbin4c)
                         absd<-abs(sum(xbin8c)/sum(nbin8c) - sum(xbin4c)/sum(nbin4c))

                         sd<-sqrt(var(mu.boot8c)+var(mu.boot4c))
                         T1<-(mu_8c-mu_4c)/sd
                         pvalue1<-2*pnorm(-abs(T1))

                         ret<-c(pvalue1,absd)
                         return(ret)
                       }

      stopCluster(cl)
      result<-cbind(result,rets)
    }
  }

  if(reg_remain!=0){
    cl <- makeCluster(reg_remain)
    registerDoParallel(cl)
    rets <- foreach (reg = (rep_count*100+1):length(testRegion), .packages=c("doParallel"),
                     .inorder =TRUE, .combine ="cbind") %dopar% {

                       eachbinn8c <- as.matrix(testRegion[[reg]]$n[, sample8c])
                       eachbinx8c <- as.matrix(testRegion[[reg]]$x[, sample8c])
                       eachbinn4c <- as.matrix(testRegion[[reg]]$n[, sample4c])
                       eachbinx4c <- as.matrix(testRegion[[reg]]$x[, sample4c])

                       #-------parameter estimate----------
                       eight_n<-NULL
                       eight_x<-NULL
                       four_n<-NULL
                       four_x<-NULL

                       for (i in 1:dim(eachbinn8c)[1]) {
                         eight_n <- c(eight_n, eachbinn8c[i,!is.na(eachbinn8c[i,])])
                         eight_x <- c(eight_x, eachbinx8c[i,!is.na(eachbinn8c[i,])])
                         four_n <- c(four_n, eachbinn4c[i ,!is.na(eachbinn4c[i,])])
                         four_x <- c(four_x, eachbinx4c[i ,!is.na(eachbinn4c[i,])])

                       }

                       discreteMM.est8c<-discreteMM.est(eight_n,eight_x,length(eight_n),
                                                        H_select(round(length(eight_n)/dim(eachbinn8c)[1]),"8cell"))
                       pai8c<-discreteMM.est8c$pai
                       phi8c<-discreteMM.est8c$phi

                       discreteMM.est4c <- discreteMM.est(four_n,four_x,length(four_n),
                                                          H_select(round(length(four_n)/dim(eachbinn8c)[1]),"4cell"))
                       pai4c<- discreteMM.est4c$pai
                       phi4c<- discreteMM.est4c$phi


                       ###----------wald test------------------------

                       mu_8c <- sum(pai8c*phi8c)
                       mu_4c <- sum(pai4c*phi4c)


                       boot_sample8c<-vector(mode="list")
                       boot_sample4c<-vector(mode="list")


                       for(g in 1:500)
                       {
                         ###8 cell
                         eight_nnew<-sample(eight_n,size=n1*dim(eachbinn8c)[1],replace = TRUE)
                         g8c<-rdiscrete.appro(length(eight_nnew),phi8c,pai8c)
                         eight_xnew<-mapply(rbinom, n = rep(1, length(eight_nnew)), size =eight_nnew, prob =g8c)

                         #ntotal8c.new<-length(eight_nnew)
                         n8c.new_each<-round(length(eight_nnew)/dim(eachbinn8c)[1])
                         boot_sample8c[[g]]<-cbind(eight_xnew,eight_nnew)


                         ###4 cell
                         four_nnew<-sample(four_n,size=n2*dim(eachbinn4c)[1],replace = TRUE)
                         g4c<-rdiscrete.appro(length(four_nnew),phi4c,pai4c)
                         four_xnew<-mapply(rbinom, n = rep(1, length(four_nnew)), size =four_nnew, prob =g4c)

                         #ntotal4c.new<-length(four_nnew)
                         n4c.new_each<-round(length(four_nnew)/dim(eachbinn4c)[1])
                         boot_sample4c[[g]]<-cbind(four_xnew,four_nnew)


                       }

                       mu.boot8c<-sapply(boot_sample8c,boot8c_discreteMM.est)
                       mu.boot4c<-sapply(boot_sample4c,boot4c_discreteMM.est)

                       ### delta ###
                       nbin8c <- NULL
                       nbin4c <- NULL
                       xbin8c <- NULL
                       xbin4c <- NULL
                       for (i in 1:dim(eachbinn8c)[2]) {
                         nbin8c <- c(nbin8c, eachbinn8c[!is.na(eachbinn8c[,  i]), i])
                         xbin8c <- c(xbin8c, eachbinx8c[!is.na(eachbinn8c[,  i]), i])
                       }
                       for (ii in 1:dim(eachbinn4c)[2]) {
                         nbin4c <- c(nbin4c, eachbinn4c[!is.na(eachbinn4c[,  ii]), ii])
                         xbin4c <- c(xbin4c, eachbinx4c[!is.na(eachbinn4c[,  ii]), ii])
                       }


                       ntotal8c <- length(nbin8c)
                       ntotal4c <- length(nbin4c)
                       absd<-abs(sum(xbin8c)/sum(nbin8c) - sum(xbin4c)/sum(nbin4c))

                       sd<-sqrt(var(mu.boot8c)+var(mu.boot4c))
                       T1<-(mu_8c-mu_4c)/sd
                       pvalue1<-2*pnorm(-abs(T1))

                       ret<-c(pvalue1,absd)
                       return(ret)
                     }

    stopCluster(cl)
  }

  finial_result<-cbind(result,rets)

  return(finial_result)
}
