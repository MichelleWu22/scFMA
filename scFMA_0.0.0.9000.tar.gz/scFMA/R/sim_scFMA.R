#' simulation experiment with scFMA
#'
#' @param testRegion the list generated after site filtering and region division
#' @param res.8c the model estimation of 8-cell samples by discrete approximation technique
#' @param res.4c the model estimation of 4-cell samples by discrete approximation technique
#' @param pio_list simulated methylation rate
#' @param n1 the sample size of the 8-cell samples
#' @param n2 the sample size of the 4-cell samples
#' @param start Starting point for groups, and 100 regions form a group
#' @param end Group endpoint
#'
#' @return pvalues, regional level methylation difference Δ(absd) between two types of samples and the parameter estimates of two type samples.
#' @export
#'
sim_scFMA<-function(testRegion,res.8c, res.4c,pio_list,n1,n2,start,end){

  finial_result<-NULL
  for(rep in start:end){

    library(foreach)
    library(iterators)
    library(parallel)
    library(doParallel)

    cl <- makeCluster(100)
    registerDoParallel(cl)
    rets <- foreach (reg = (1+100*(rep-1)):(100*rep), .packages=c("doParallel"),
                     .inorder =TRUE, .combine ="cbind") %dopar% {

                       library(scFMA)
                       qujian<-10
                       eachbinn48c <- as.matrix(testRegion[[reg]]$n)
                       eachbinx48c <- as.matrix(testRegion[[reg]]$x)
                       result8c<-res.8c[reg,]
                       result4c<-res.4c[reg,]
                       pio<-pio_list[[reg]]

                       eachbinn8c<-eachbinn48c[,1:n1]
                       eachbinn4c<-eachbinn48c[,(n1+1):(n1+n2)]
                       eachbinx8c<-eachbinx48c[,1:n1]
                       eachbinx4c<-eachbinx48c[,(n1+1):(n1+n2)]
                       ###-----------------------------------wald test------------------------------------------

                       H8c<-H_select(n1,"8cell")
                       H4c<-H_select(n2,"4cell")
                       phi8c<-phi.est(H8c)$phi
                       phi4c<-phi.est(H4c)$phi
                       pai8c<-result8c[-1]
                       pai4c<-result4c[-1]

                       mu_8c <- sum(result8c[-1]*phi8c)
                       mu_4c <- sum(result4c[-1]*phi4c)

                       boot_sample8c<-vector(mode="list")
                       boot_sample4c<-vector(mode="list")


                       for(g in 1:500)
                       {

                         ###8 cell
                         nx8c_new<-matrix(0,qujian,n1)
                         for(i in 1:qujian)
                         {

                           g8c<-sample(pio$pio.8c,size=n1,replace = TRUE)
                           nx8c<-eachbinn48c[i,1:n1]
                           nx8c[g8c==0]<-0
                           nn1<-nx8c[g8c>0 & g8c<1]
                           nx8c[g8c>0 & g8c<1]<-mapply(rbinom, n = rep(1, length(nn1)), size =nn1, prob =g8c[g8c>0 & g8c<1])
                           nx8c_new[i,]<-nx8c

                           nx8c_new[i,]<-mapply(rbinom, n = rep(1, length(n1)), size =eachbinn48c[i,1:n1], prob =g8c)
                         }



                         eachbinn8c.new<-as.matrix(eachbinn48c[,1:n1])
                         eight_nnew<-NULL
                         eight_xnew<-NULL

                         for(j in 1:dim(eachbinn8c.new)[2])
                         {
                           eight_nnew<-c(eight_nnew, eachbinn8c.new[!is.na(eachbinn8c.new[,j]),j])
                           eight_xnew<-c(eight_xnew, nx8c_new[!is.na(nx8c_new[,j]),j])
                         }

                         ntotal8c.new<-length(eight_nnew)
                         boot_sample8c[[g]]<-cbind(eight_xnew,eight_nnew)


                         ###4 cell

                         nx4c_new<-matrix(0,qujian,n2)
                         for(i in 1:qujian){

                           g4c<-sample(pio$pio.4c,size=n2,replace = TRUE)
                           nx4c<-eachbinn48c[i,(n1+1):(n1+n2)]
                           nx4c[g4c==0]<-0
                           nn2<-nx4c[g4c>0 & g4c<1]
                           nx4c[g4c>0 & g4c<1]<-mapply(rbinom, n = rep(1, length(nn2)), size =nn2, prob =g4c[g4c>0 & g4c<1])
                           nx4c_new[i,]<-nx4c

                           nx4c_new[i,]<-mapply(rbinom, n = rep(1, length(n2)), size =eachbinn48c[i,(n1+1):(n1+n2)], prob =g4c)
                         }

                         eachbinn4c.new<-as.matrix(eachbinn48c[,(n1+1):(n1+n2)])
                         four_nnew<-NULL
                         four_xnew<-NULL

                         for(j in 1:dim(eachbinn4c.new)[2])
                         {
                           four_nnew<-c(four_nnew, eachbinn4c.new[!is.na(eachbinn4c.new[,j]),j])
                           four_xnew<-c(four_xnew, nx4c_new[!is.na(nx4c_new[,j]),j])
                         }

                         ntotal4c.new<-length(four_nnew)
                         boot_sample4c[[g]]<-cbind(four_xnew,four_nnew)

                       }


                       mu.boot8c<-sapply(boot_sample8c,boot8c_discreteMM.est) #G results
                       mu.boot4c<-sapply(boot_sample4c,boot4c_discreteMM.est)


                       T<-mean(mu.boot8c-mu.boot4c)/sd(mu.boot8c-mu.boot4c)
                       pvalue<-2*pnorm(-abs(T))


                       ##Δ
                       meansamplep8c<-NULL
                       meansamplep4c<-NULL

                       for (j in 1:n1) {
                         n8c<-sum(eachbinn48c[!is.na(eachbinn48c[,j]),j])
                         x8c<-sum(eachbinx48c[!is.na(eachbinx48c[,j]),j])
                         meansamplep8c<- c(meansamplep8c, (x8c+0.00001)/n8c)
                       }

                       for (j in (n1+1):(n1+n2)) {
                         n4c<-sum(eachbinn48c[!is.na(eachbinn48c[,j]),j])
                         x4c<-sum(eachbinx48c[!is.na(eachbinx48c[,j]),j])
                         meansamplep4c<- c(meansamplep4c, (x4c+0.00001)/n4c)
                       }
                       absd<-abs((sum(eachbinx48c[,1:n1])/sum(eachbinn48c[,1:n1]))-(sum(eachbinx48c[,(n1+1):(n1+n2)])/sum(eachbinn48c[,(n1+1):(n1+n2)])))


                       ret<-c(pvalue,absd,result8c,result4c)

                       return(ret)
                     }

    stopCluster(cl)
    finial_result<-cbind(finial_result,rets)
  }
  finial_result<-as.data.frame(finial_result)
  return(finial_result)
}
