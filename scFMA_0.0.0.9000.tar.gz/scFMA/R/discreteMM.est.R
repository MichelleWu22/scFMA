
#' discrete approximation techinique with MM algorithm
#'
#' @param n_read total reads
#' @param x_read methylation reads
#' @param n sample size
#' @param H the number of interval midpoint
#'
#' @return probability value of the interval(pai) and the vector composed of interval midpoints(phi)
#' @export
#'
discreteMM.est<-function(n_read,x_read,n,H){

  phi<-phi.est(H)$phi
  tau<-phi.est(H)$tau
  M<-phi.est(H)$M

  #inital value
  pai=pai.ini=rep(1/H,H)


  error=3

  while( error>10^(-4) )
  {
    Pai<-matrix(0,n,H)
    nu<-matrix(0,n,H)

    ppai<-t(matrix(rep(pai,each=n),H,n,byrow=TRUE))
    Tau<-t(matrix(rep(tau,each=n),M,n,byrow=TRUE))
    Phi<-t(matrix(rep(phi,each=n),H,n,byrow=TRUE))
    X_read<-t(array(rep(x_read,each=H),c(length(phi),n)))
    N_read<-t(array(rep(n_read,each=H),c(length(phi),n)))

    Pai<-ppai*(Phi^X_read)*((1-Phi)^(N_read-X_read))
    nu<-Pai/(t(matrix(rep(rowSums(Pai),each=H),H,n)))

    pai.est<-colSums(nu)/n
    if(all(is.na(pai.est))) pai.est<-pai.ini


    error<-sum(abs(pai.est-pai))

    pai<-pai.est
  }
  return(list(pai=pai,phi=phi))
}
